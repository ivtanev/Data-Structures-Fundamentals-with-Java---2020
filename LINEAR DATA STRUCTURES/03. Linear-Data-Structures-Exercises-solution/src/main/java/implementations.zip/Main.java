import implementations.ArrayDeque;
import implementations.DoublyLinkedList;

public class Main {
    public static void main(String[] args) {
        ArrayDeque<Integer> deque = new ArrayDeque<>();
        deque.offer(10);
        deque.offer(11);
        deque.offer(12);
        deque.offer(13);
        deque.offer(14);

        for (Integer integer : deque) {
            System.out.println(integer);
        }
    }
}
