import implementations.ArrayDeque;
import implementations.BalancedParentheses;
import implementations.DoublyLinkedList;
import implementations.ReversedList;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        //{[(])}
        String input = "{[()]}";
        BalancedParentheses balancedParentheses = new BalancedParentheses(input);
        System.out.println(balancedParentheses.solve());
    }
}
