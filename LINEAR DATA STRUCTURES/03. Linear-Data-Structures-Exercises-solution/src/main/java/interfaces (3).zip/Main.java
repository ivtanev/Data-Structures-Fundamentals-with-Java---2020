import implementations.ArrayDeque;
import implementations.DoublyLinkedList;
import implementations.ReversedList;

public class Main {
    public static void main(String[] args) {
//        ReversedList<Integer> reversedList = new ReversedList<>();
//        ArrayDeque<Integer> deque = new ArrayDeque<>();
//        reversedList.Add(10);
//        reversedList.Add(11);
//        reversedList.Add(12);
//        reversedList.Add(13);
//        reversedList.Add(14);
//        reversedList.Add(15);
//        reversedList.Add(16);
//        reversedList.Add(17);
//
//        System.out.println(reversedList.Size());
//        System.out.println(reversedList.Capacity());
//        System.out.println(reversedList.RemoveAt(3));
//        System.out.println(reversedList.Get(3));
//
//        for (Integer integer : reversedList) {
//            System.out.println(integer);
//        }
    }
}
