import implementations.ArrayDeque;
import implementations.DoublyLinkedList;
import implementations.ReversedList;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        ReversedList<Integer> reversedList = new ReversedList<>();
        ArrayDeque<Integer> deque = new ArrayDeque<>();
        reversedList.add(10);
        reversedList.add(11);
        reversedList.add(12);
        reversedList.add(13);
        reversedList.add(14);
        reversedList.add(15);
        reversedList.add(16);
        reversedList.add(17);

        //System.out.println(reversedList.size());
        //System.out.println(reversedList.capacity());
        System.out.println(reversedList.removeAt(3));
        //System.out.println(reversedList.get(3));

        for (Integer integer : reversedList) {
            System.out.println(integer);
        }
    }
}
