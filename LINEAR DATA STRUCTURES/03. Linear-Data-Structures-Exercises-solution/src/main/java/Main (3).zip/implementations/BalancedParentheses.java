package implementations;

import interfaces.Solvable;

public class BalancedParentheses implements Solvable {
    private String parentheses;

    public BalancedParentheses(String parentheses) {
        this.parentheses = parentheses;
    }

    @Override
    public Boolean solve() {
        if (this.parentheses.isEmpty()) {
            return false;
        } else {
            for (int i = 0; i < this.parentheses.length() / 2; i++) {
                char first = this.parentheses.charAt(i);
                if (first != '{' && first != '(' && first != '[') {
                    return false;
                }
                char second = this.parentheses.charAt(parentheses.length() - 1 - i);
                switch (first) {
                    case '{':
                        if (second != '}') {
                            return false;
                        }
                        break;
                    case '[':
                        if (second != ']') {
                            return false;
                        }
                        break;
                    case '(':
                        if (second != ')') {
                            return false;
                        }
                        break;
                }
            }
        }
        return true;
    }
}
